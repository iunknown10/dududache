﻿
var PageName = '新建页面 1';
var PageId = '23d34393f6854a6699b87fae0582c6ee'
var PageUrl = '新建页面_1.html'
document.title = '新建页面 1';
var PageNotes = {};

if (window.OnLoad) OnLoad();
