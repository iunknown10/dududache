﻿
var PageName = '新建页面 2';
var PageId = 'b2122b74d2444d7797e32c826079e4f7'
var PageUrl = '新建页面_2.html'
document.title = '新建页面 2';
var PageNotes = {};

if (window.OnLoad) OnLoad();
